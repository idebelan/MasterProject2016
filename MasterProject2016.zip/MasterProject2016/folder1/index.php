﻿<!DOCTYPE html>
<html> 
  <head>
  <meta charset="utf-8">
  <title>HS-Fulda-Project-2016(Project Team Page)</title> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
  <!-- 
  ========== !!! local bootstrap instalation !!! ========== 
  <link rel="stylesheet" href="../bootstrap/3.3.7/css/bootstrap.min.css"> 
  <link rel="stylesheet" href="../bootstrap/3.3.7/css/bootstrap-theme.min.css"> 
  <script src="../jquery/1.12.4/jquery.min.js"></script>  
  <script src="../bootstrap/3.3.7/js/bootstrap.min.js"></script> 
  ========== !!! local bootstrap instalation !!! ========== 
  -->
  
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" > 
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" > 
  <!-- jQuery -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> 
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" > </script> 
  
  <style> ul#social_links li { display:inline; } </style>
  </head>
<body>
  <?php
    // index.php 2016-10-25 16:00:00 ivan 
    // $FROMreferer   = 'folder1-page' ;
    // include 'register_the_visit.php';
  ?>
  <script>
    $(document).ready(function(){ $('[data-toggle="tooltip"]').tooltip(); });
  </script>
  <div class="container">
    <div class="row">
      <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1"> 
        <!-- empty -->
      </div> <!-- column -->
      
      <div class="col-xs-10 col-sm-10 col-md-10 col-lg-10"> 
            
        <hr style="height:5px; color: #123455; background-color: #123455; border: none;">
        <img class="img-responsive" src="../media/LOGO-modified-Fulda.png" width="940" height="200" alt="Project2016-logo">
        
        <h1 id="site-title">
          <span> Appartments searching in Fulda - Student Project 2016</span>
        </h1>
        
        <div style="background-color:black; color:white; padding:10px;">
          <ul class="nav nav-pills">
            <li> <a data-toggle="pill" href="#" onclick="location.href='/MasterProject2016';">Main-Page</a></li>
            <li> <a data-toggle="pill" href="#" onclick="location.href='/MasterProject2016/folder2/';">Result from Search</a></li>
            <li> <a data-toggle="pill" href="#" onclick="location.href='/MasterProject2016/folder3/';">Login-Overview</a></li>
            <li> <a data-toggle="pill" href="#" onclick="location.href='/MasterProject2016/folder4/';">Flat-Ad-Insert</a></li>
            <li> <a data-toggle="pill" href="#" onclick="location.href='/MasterProject2016/folder5/';">Flat-Ad-Remove</a></li>
            <li> <a data-toggle="pill" href="#" onclick="location.href='/MasterProject2016/folder6/';">Flat-Book</a></li>
            <li class="active"> <a data-toggle="pill" href="#active-content">Mster-Project-Team</a></li>
          </ul>
        </div>
        
        <!-- INSIDE THE MENU ITEMS -->
        <div class="tab-content">
          <div id="active-content" class="tab-pane fade in active">

          <div>
            <h3><strong>Project Team - Presentation Page</strong></h3>
            <img class="img-responsive" src="../media/PIC-under-construction.jpg" alt="MasterProject2016"> 
          </div>
              
          </div> <!-- active-content -->
        </div> <!-- tab-content -->
 
    <!-- FOOTER [BEGIN] -->
    <footer class="container-fluid bg-4 text-left">
      <p>
        FOLLOW US:  
        <a target="_blank" href=""> <img src="../media/facebook-icon.png"  alt="facebook"/>  </a>
        <a target="_blank" href=""> <img src="../media/twitter-icon.png"   alt="twitter"/>   </a>
        <a target="_blank" href=""> <img src="../media/instagram-icon.png" alt="instagram"/> </a>
        powered by Group3 Project 2016
        &copy; 2016-<?php echo date("Y");?>  
      </p>
      <hr style="height:2px; color: #123455; background-color: #123455; border: none;">
            <div class="table-responsive">
              <table class="table">
                <tbody>
                  <tr class="warning">  
                    <td>   <!-- <td 1>    -->
                      <h5><strong>Interessting Links</strong></h5>
                      <ul>
                        <li><a href="http://www.atmforum.com/" data-toggle="tooltip" title="ATM-Forum" target="_blank">ATM-Forum</a></li>
                        <li><a href="http://www.fcc.gov/"      data-toggle="tooltip" title="Federal Communications Commission (FCC)" target="_blank">Federal Communications Commission (FCC)</a></li>
                        <li><a href="http://www.ieee.org/"     data-toggle="tooltip" title="Institute of Electrical and Electronics Engineers (IEEE)" target="_blank">Institute of Electrical and Electronics Engineers (IEEE)</a></li>
                        <li><a href="http://www.computer.org/" data-toggle="tooltip" title="IEEE Computer Society" target="_blank">IEEE Computer Society</a></li>
                        <li><a href="http://www.itu.ch/"       data-toggle="tooltip" title="International Telecommunication Union (ITU)" target="_blank">International Telecommunication Union (ITU)</a></li>
                        <li><a href="http://www.isoc.org/"     data-toggle="tooltip" title="Internet Society" target="_blank">Internet Society</a></li>
                      </ul>
                    </td>
                    
                    <td>  <!-- <td 2>    -->
                      <h5><strong>Other Stuff</strong></h5>
                      <ul>
                        <li><a href="https://www.hs-fulda.de/"      data-toggle="tooltip" title="The university of Fulda" title="The university of Fulda">hs-fulda.de</a></li>
                        <li><a href="http://php.net/"               data-toggle="tooltip" title="Real Web-Scripting Power: PHP" title="Real Web-Scripting Power: PHP">Scripting the Web: PHP</a></li>
                        <li><a href="https://www.bootstrapcdn.com/" data-toggle="tooltip" title="Real Web-Styling Power: Bootstrap" title="Real Web-Styling Power: Bootstrap">Styling the Web: Bootstrap</a></li>
                      </ul>
                    </td>  
                  </tr>
                </tbody>
              </table>
            </div> <!-- table -->
      <hr style="height:3px; color: #123455; background-color: #123455; border: none;">
    </footer>
    <!-- FOOTER [END] -->
  
  </div> <!-- column -->
  
      <div class="col-xs-1 col-sm-1 col-md-1 col-lg-1"> 
        <!-- empty -->
      </div>  <!-- column -->
    </div>  <!-- row -->
  </div>  <!-- container -->
</body>
</html>
<!-- 25-10-2016 -->
